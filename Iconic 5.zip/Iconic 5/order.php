<!DOCTYPE html>
<html>
<head>
  <title>Order Summary</title>
  <link rel="stylesheet" type="text/css" href="Orderstyles.css">
</head>
<body>
  <h1>Order Summary</h1>

  <?php
  if(isset($_POST['submit']) && isset($_POST['items'])) {
    $items = $_POST['items'];

    echo "<p>Your selected items:</p>";
    echo "<ul>";
    foreach($items as $item) {
      echo "<li>$item</li>";
    }
    echo "</ul>";
  } else {
    echo "<p>No items selected.</p>";
  }
  ?>

  <p>Thank you for your order!</p>
</body>
</html>
