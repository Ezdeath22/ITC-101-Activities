<!DOCTYPE html>
<html>
<head>
  <title>Fast Food Order System</title>
  <link rel="stylesheet" type="text/css" href="Orderstyles.css">
</head>
<body>
<ul class="navbar">
<li> <img src="images/iconic5logo.jpg" alt="logos" style="width: 60px; height: 60px; margin-top: 7px">
 </li>
    <li><a href="#home">Home</a></li>
    <li><a href="#products">Products</a></li>
    <li><a href="#contacts">Contacts</a></li>
    <li><a href="#about">About Us</a></li>
    </ul>
  <form method="post" action="order.php">
    <div class="menu">
    <div class="item">
  <a href="Burger.php">
    <img src="images/burgers.jpg" alt="burgers">
  </a>
<br>
  <label for="burger">Burger</label>
</div>

      <div class="item">
        <img src="images/fries.jpg" alt="Fries">
        <br>
        <label for="fries">Fries</label>
      </div>
      <div class="item">
        <img src="images/cake.jpg" alt="Cake">
        <br>
        <label for="cake">Cake</label>
      </div>
      <div class="item">
        <img src="images/pizza.jpg" alt="Pizza">
        <br>
        <label for="pizza">Pizza</label>
      </div>
    </div>
<br>
<div class="menu">
<div class="item">
        <img src="images/Milktea.jpg" alt="Milktea">
        <br>
        <label for="milktea">Milktea</label>
      </div>
    <div class="item">
        <img src="images/Milkshakes.jpg" alt="Milkshakes">
        <br>
        <label for="milkshakes">Milkshakes</label>
      </div>
      <div class="item">
        <img src="images/Coffee.jpg" alt="Coffee">
        <br>
        <label for="coffee">Coffee</label>
      </div>
      <div class="item">
        <img src="images/Soup.jpg" alt="Soup">
        <br>
        <label for="soup">Soup</label>
      </div>
      </div>
    
    </form>
  
        
</body>
</html>
