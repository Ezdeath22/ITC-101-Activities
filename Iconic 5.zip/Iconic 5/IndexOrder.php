<!DOCTYPE html>
<html>
<head>
  <title>Fast Food Order System</title>
  <link rel="stylesheet" type="text/css" href="Orderstyles.css">
</head>
<body>
<ul class="navbar">
<img src="images/iconic5logo.jpg" alt="logos">   
    <li><a href="#home">Home</a></li>
    <li><a href="#products">Products</a></li>
    <li><a href="#contacts">Contacts</a></li>
    <li><a href="#about">About Us</a></li>
    </ul>
  <form method="post" action="order.php">
    <div class="menu">
    <div class="item">
  <a href="Burger.php">
    <img src="images/burgers.jpg" alt="burgers">
  </a>
  <input type="checkbox" name="items[]" value="Burger">
  <label for="burger">Burger</label>
</div>

      <div class="item">
        <img src="fries.jpg" alt="Fries">
        <input type="checkbox" name="items[]" value="Fries">
        <label for="fries">Fries</label>
      </div>
      <div class="item">
        <img src="drink.jpg" alt="Drink">
        <input type="checkbox" name="items[]" value="Drink">
        <label for="drink">Drink</label>
      </div>
    </div>

    <input type="submit" name="submit" value="Place Order">
  </form>
</body>
</html>
