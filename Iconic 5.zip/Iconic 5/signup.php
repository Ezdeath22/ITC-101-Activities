<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Retrieve form data
  $firstname = $_POST["firstname"];
  $middlename = $_POST["middlename"];
  $lastname = $_POST["lastname"];
  $birthday = $_POST["birthday"];
  $place = $_POST["place"];
  $contact = $_POST["contact"];
  $contact_code = $_POST["contact_code"];
  $email = $_POST["email"];
  $email_code = $_POST["email_code"];
  $username = $_POST["username"];

  // Perform authentication and validation here
  // ...

  // Process the data (e.g., save to a database)

  // Redirect to a success page
  header("Location: success.html");
  exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<head>
  <title style="color: white;">Sign Up</title>
  <link rel="stylesheet" type="text/css" href="indexstyles.css">
</head>
<body>
  <div class="container">
    <h1 style="color: white;">Sign Up</h1>
    <form action="signup.php" method="POST">
      <label for="firstname" style="color: white;">First Name:</label>
      <input type="text" id="firstname" name="firstname" placeholder="Enter your first name" required>

      <label for="middlename" style="color: white;">Middle Name:</label>
      <input type="text" id="middlename" name="middlename" placeholder="Enter your middle name" required>

      <label for="lastname" style="color: white;">Last Name:</label>
      <input type="text" id="lastname" name="lastname" placeholder="Enter your last name" required>

      <label for="birthday" style="color: white;">Birthday:</label>
      <input type="date" id="birthday" name="birthday" required>

      <label for="place" style="color: white;">Place:</label>
      <input type="text" id="place" name="place" placeholder="Enter your place" required>

      <label for="contact" style="color: white;">Contact Number:</label>
      <input type="text" id="contact" name="contact" placeholder="Enter your contact number" required>

      <label for="contact_code" style="color: white;">Contact Code:</label>
      <input type="text" id="contact_code" name="contact_code" placeholder="Enter your contact code" required>

      <label for="email" style="color: white;">Email Address:</label>
      <input type="email" id="email" name="email" placeholder="Enter your email address" required>

      <label for="email_code" style="color: white;">Email Code:</label>
      <input type="text" id="email_code" name="email_code" placeholder="Enter your email code" required>

      <label for="username" style="color: white;">Username:</label>
      <input type="text" id="username" name="username" placeholder="Enter your username" required>

      <input type="submit" value="Sign up">
    </form>
    <p style="color: white;">Already have an account? <a href="index.php" style="color: white;">Log in</a></p>
  </div>
  </div>
</body>
</html>
