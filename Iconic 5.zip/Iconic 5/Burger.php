<!DOCTYPE html>
<html>
<head>
  <title>Burger Ordering System</title>
</head>
<body>
  <?php
  // Burger variants array
  $burgers = array(
    array(
      'name' => 'Burger 1',
      'image' => 'images/burger1.jpeg',
      'price' => 8.99
    ),
    array(
      'name' => 'Burger 2',
      'image' => 'images/burger2.jpeg',
      'price' => 9.99
    ),
    array(
      'name' => 'Burger 3',
      'image' => 'images/burger3.jpeg',
      'price' => 7.99
    )
  );

  // Process the form submission
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selectedBurger = $_POST["burger"];
    $quantity = $_POST["quantity"];
    $totalPrice = $burgers[$selectedBurger]['price'] * $quantity;

    echo "<h2>Your Order</h2>";
    echo "<p>Burger: " . $burgers[$selectedBurger]['name'] . "</p>";
    echo "<p>Quantity: " . $quantity . "</p>";
    echo "<p>Total Price: $" . $totalPrice . "</p>";
  }
  ?>

  <h2>Choose a Burger</h2>
  <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <?php
    // Display burger variants
    foreach ($burgers as $key => $burger) {
      echo '<div class="item">';
      echo '<label for="burger' . $key . '">';
      echo '<img src="' . $burger['image'] . '" alt="' . $burger['name'] . '">';
      echo '</label>';
      echo '<input type="radio" id="burger' . $key . '" name="burger" value="' . $key . '" required>';
      echo '<label for="burger' . $key . '">' . $burger['name'] . '</label>';
      echo '</div>';
    }
    ?>

    <h2>Quantity</h2>
    <input type="number" name="quantity" min="1" max="10" required>

    <input type="submit" value="Place Order">
  </form>

  <h2>Price List</h2>
  <table>
    <thead>
      <tr>
        <th>Burger</th>
        <th>Price</th>
      </tr>
    </thead>
    <tbody>
      <?php
      // Display price list
      foreach ($burgers as $burger) {
        echo '<tr>';
        echo '<td>' . $burger['name'] . '</td>';
        echo '<td>$' . $burger['price'] . '</td>';
        echo '</tr>';
      }
      ?>
    </tbody>
  </table>
</body>
</html>
